# 📈 SOFR Dashboard — Prueba Técnica

Panel web interactivo que obtiene, mantiene y visualiza el histórico diario de la tasa **SOFR** (Secured Overnight Financing Rate) desde la **API oficial de FRED** (Federal Reserve Bank of St. Louis).

---

## 📁 Estructura del proyecto

```
get_sofr/
├── get_sofr.py          ← Script original (NO modificado)
├── app.py               ← Servidor Flask que envuelve get_sofr.py
├── requirements.txt     ← Dependencias Python
├── templates/
│   └── index.html       ← Frontend premium del dashboard
└── README.md            ← Este archivo
```

---

## ⚙️ Requisitos previos

- **Python 3.10 o superior**  
  Descárgalo desde: https://www.python.org/downloads/  
  ⚠️ Durante la instalación, marca la opción **"Add Python to PATH"**

---

## 🚀 Instalación y ejecución

### 1. Abrir terminal en la carpeta del proyecto

```powershell
# Windows: Navega hasta la carpeta del proyecto
cd C:\ruta\al\proyecto\get_sofr
```

### 2. (Opcional pero recomendado) Crear entorno virtual

```powershell
python -m venv venv
venv\Scripts\activate
```

### 3. Instalar dependencias

```powershell
pip install -r requirements.txt
```

### 4. Lanzar el servidor

```powershell
python app.py
```

Verás en la terminal:
```
 * Running on http://127.0.0.1:5000
```

### 5. Abrir el dashboard en el navegador

Visita: **http://localhost:5000**

---

## 🖥️ Funcionalidades del Dashboard

| Acción | Descripción |
|--------|-------------|
| **⟳ Actualizar datos** | Llama al script original y actualiza `historico_sofr.xlsx` con los datos más recientes de FRED |
| **⬇ Descargar Excel** | Descarga directa del archivo `historico_sofr.xlsx` generado |
| **↺ Refrescar gráfico** | Recarga el gráfico con el archivo Excel existente sin hacer nueva petición a FRED |
| **Filtros 3M / 6M / 1A / 3A / Todo** | Filtra el gráfico por ventana de tiempo |
| **Zoom con scroll** | Zoom interactivo sobre el gráfico (rueda del ratón) |

---

## 🔑 API Key de FRED

La clave API ya está configurada directamente en `get_sofr.py`:

```python
API_KEY = "d63d54ada6ed77d8f3b400c68d0e663f"
```

Si deseas usar tu propia clave, regístrate gratis en:  
https://fred.stlouisfed.org/docs/api/api_key.html

---

## 📝 Uso del script original sin el dashboard

El script `get_sofr.py` también puede ejecutarse directamente desde terminal:

```powershell
python get_sofr.py
```

Esto creará o actualizará `historico_sofr.xlsx` sin necesidad de abrir el navegador.

---

## ❓ Preguntas frecuentes

**¿Se modificó `get_sofr.py`?**  
No. El archivo original permanece **idéntico**. `app.py` lo importa como módulo y llama a su función `update_sofr_official_api()`.

**¿Dónde se guarda el Excel?**  
En la misma carpeta del proyecto, como `historico_sofr.xlsx`.

**¿El servidor necesita internet?**  
Solo cuando presionas **Actualizar datos**. El gráfico y la tabla se pueden cargar offline si el Excel ya existe.

---

*Desarrollado con Flask + Chart.js · Datos oficiales FRED (Federal Reserve Bank of St. Louis)*
